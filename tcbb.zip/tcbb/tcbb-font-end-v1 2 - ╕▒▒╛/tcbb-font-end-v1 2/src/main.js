import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import installElementPlus from './plugins/element'
import i18n from '@/i18n'
// 导入路由鉴权
import './permission'
// 初始化样式表
import '@/styles/index.scss'
// 导入svgIcon
/**
 * installIcons 是一个函数
 * 使用这个该函数
 */
import installIcons from '@/icons'
window.router = router

const app = createApp(App)
installIcons(app)
installElementPlus(app)
app.use(store).use(router).use(i18n).mount('#app')
