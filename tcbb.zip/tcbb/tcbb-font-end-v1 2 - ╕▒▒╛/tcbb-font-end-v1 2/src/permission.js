/**
 * 专门处理路由守卫
 * 和已经登录后一些用户信息的处理
 */
import router from '@/router'
import store from '@/store'
/**
 * 路由前置守卫
 * to: 到哪里去
 * from： 从哪里来
 * next： 是否要进行转跳
 */
router.beforeEach(async (to, from, next) => {
  // 1 用户已登录，则不允许进入login
  // 2 用户未登录，则只允许进入login
  // 可使用token进行判断用户是否已登录
  if (store.getters.token) {
    console.log(store.getters.token)
    // 1 用户已登录，则不允许进入login
    if (to.path === '/login') {
      next('/')
    } else {
      // 判断用户资料是否存在，如果不存在，则获得用户信息
      // 判断store.getters.hasUserInfo
      console.log(store.getters.hasUserInfo)
      if (!store.getters.hasUserInfo) {
        console.log(!store.getters.hasUserInfo)
        await store.dispatch('user/getUserInfo')
      }
      next()
    }
  } else {
    // 2 用户未登录，则只允许进入login
    if (to.path === '/login' || to.path === '/404') {
      next()
    } else {
      next('/login')
    }
  }
})
