/**
 * 此模块用于课程充值和赠送，终止课程 修改课程等
 */
import request from '@/utils/request'

/**
 * 通过user 的 ID值获得该学员充值课程总数和赠送课程总数
 */
export const getBuycouresById = data => {
  console.log(data)
  return request({
    url: '/course/getBuycouresListById',
    method: 'POST',
    data
  })
}

/**
 * 课程充值模块
 */
export const createInvestMoney = data => {
  console.log(data)
  return request({
    url: '/course/createInvestMoney',
    method: 'POST',
    data
  })
}
