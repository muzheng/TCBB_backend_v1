/**
 * 导入封装好的axios
 * 重新封装的axios已经进行过滤处理
 */
import request from '@/utils/request'

/**
 * 登录
 */
export const login = data => {
  return request({
    url: '/login/login',
    method: 'POST',
    data
  })
}

/**
 * 获取用户信息
 */
export const getUserInfo = data => {
  return request({
    url: '/login/profile',
    method: 'GET',
    data
  })
}
