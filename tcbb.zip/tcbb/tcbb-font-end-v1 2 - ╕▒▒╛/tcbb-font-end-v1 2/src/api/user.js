import request from '@/utils/request'
/**
 * 删除头像，文件等
 */
export const removeAvatar = data => {
  return request({
    url: '/user/remove',
    method: 'POST',
    data
  })
}

/**
 * 创建超级管理员
 */
export const createSuperAdmin = data => {
  console.log(data)
  return request({
    url: '/user/remove',
    method: 'POST',
    data
  })
}
