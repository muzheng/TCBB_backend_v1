/**
 * 创建一个数据源
 * @type {{en: {msg: {test: string}}, zh: {msg: {test: string}}}}
 */

import { createI18n } from 'vue-i18n'
import mZhLocale from './lang/zh'
import mEnLocale from './lang/en'
const messages = {
  en: {
    msg: {
      ...mEnLocale
    }
  },
  zh: {
    msg: {
      ...mZhLocale
    }
  }
}

/**
 * 创建locale 语言变量，初始为英文
 */
const locale = 'zh'

/**
 * 初始化一个i18n 实例
 */

const i18n = createI18n({
  // 使用 composition API
  legacy: false,
  // 全局使用 t 函数
  globalInjection: true,
  locale,
  messages
})
/**
 * 导出i18n
 * 然后在main.js
 * 中注册 i18n
 */
export default i18n
