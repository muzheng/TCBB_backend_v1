/**
 * 此模块用于左侧菜单栏动态收缩
 *  sidebarOpend: true 菜单打开状态
 *  triggerSidebarOpened 上面小图标的变化
 *  创建国际化的语言包,状态与本地缓存
 */
import { getItem, setItem } from '@/utils/storage'
import { LANG } from '@/constant'
export default {
  namespaced: true,
  state: () => ({
    sidebarOpened: true,
    // 获得本地的LANG的数据，如果不存在直接为zh 即中文语言包标识
    language: getItem(LANG) || 'zh'
  }),
  mutations: {
    triggerSidebarOpened (state) {
      state.sidebarOpened = !state.sidebarOpened
    },
    // 保存语言标识到stroge中
    setLanguage (state, lang) {
      setItem(LANG, lang)
      state.language = lang
    }

  },
  actions: {}
}
