/**
 * vuex模块
 * 处理和用户相关的事
 * 初始话模块
 * namespaced: true 表示为单独的模块，不会被合并到主模块中去
 * actions 里面可以封装登录等一些动作
 * 在actions中不直接保存token等数据，直接将数据保存在mutations中即可
 */
import { login, getUserInfo } from '@/api/sys'
import { setItem, getItem, removeAllItem } from '@/utils/storage'
import { setTimeStamp } from '@/utils/auth'
// TOKEN在constant中定义的常量
import { TOKEN } from '@/constant'
import router from '@/router'

// import md5 from 'md5'
export default {
  namespaced: true,
  state: () => ({
    // 先尝试获得token 或者为空时候再存储token
    token: getItem(TOKEN) || '',
    // 定义一个空对象，为以后保存userInfo数据
    userInfo: {}
  }),
  mutations: {
    setToken (state, token) {
      state.token = token
      // 将token数据保存在localStroage中
      setItem(TOKEN, token)
    },
    // 将userInfo 保存在state 中
    setUserInfo (state, userInfo) {
      state.userInfo = userInfo
    }
  },
  actions: {
    /**
     * 登录请求动作
     * @param context
     * @param userInfo
     * @returns {Promise<unknown>}
     */
    login (context, userInfo) {
      const { username, password } = userInfo
      // return new Promise()，来处理.then .catch等情况
      return new Promise((resolve, reject) => {
        login({
          username,
          // password: md5(password)
          password
        }).then(data => {
          console.log(data)
          // 触发mutations 使用this.commit（）进行保存
          this.commit('user/setToken', data.token)
          // 进行转跳操作，使用router进行，在import进行注册
          router.push('/')
          console.log(data.token)
          // 保存登陆时间
          setTimeStamp()
          resolve()
        }).catch(err => {
          reject(err)
        })
      })
    },

    /**
     * 获取用户信息动作
     * 获取到的信息保存到 vuex 的 mutations 中
     */
    async getUserInfo (context) {
      const res = await getUserInfo()
      console.log(res)
      this.commit('user/setUserInfo', res)
      console.log(this.state)
      return res
    },

    /**
     * 退出登录
     * 清理掉当前用户的缓存数据
     * 包含token 和userInfo 本地缓存存入到stroge中
     * 清理掉权限相关配置
     * 返回到登录页
     */
    logout () {
      // 清理缓存数据
      this.commit('user/setToken', '')
      this.commit('user/setUserInfo', {})
      removeAllItem()

      // TODO 需要处理权限相关数据
      // 返回登录页
      router.push('/login')
    }
  }
}
