/**
 * 定义一些快捷访问、
 * 在src-->store-->index中注册该快捷访问
 */
import variables from '@/styles/variables.scss'
const getters = {
  token: state => state.user.token,
  userInfo: state => state.user.userInfo,
  cssVar: state => variables,
  sidebarOpened: state => state.app.sidebarOpened,
  language: state => state.app.language,

  // 用户信息的属性，通过JSON.stringify 进行转换,通过判断userInfo 不为空，表示用户信息存在
  hasUserInfo: state => {
    // 返回一个true 或者 false
    return JSON.stringify(state.user.userInfo) !== '{}'
  }
}

/**
 * 导出 getters
 */
export default getters
