/**
 * storage 的作用是将token保存在浏览器本地，方便实现自动登录功能
 * 在浏览器中localStorage中有setItem，getItem 等方法
 * vuex负责数据共享，当刷新浏览器后数据消失，无法持久化保存
 */
/**
 * 存储数据
 */
export const setItem = (key, value) => {
  // value 分为两种情况，
  // 1 基本数据类型
  // 2 复杂数据类型 复杂类型，需要进行数据转换，转换为JSON格式的字符串,在保存到window.localStroge中
  if (typeof value === 'object') {
    value = JSON.stringify(value)
  }
  window.localStorage.setItem(key, value)
}

/**
 * 获取数据
 * 将JSON字符串转换为JSON格式
 * 思路为如果能转换则转换，不能转换就弹出err，直接返回
 */
export const getItem = key => {
  const data = window.localStorage.getItem(key)
  try {
    return JSON.parse(data)
  } catch (err) {
    return data
  }
}

/**
 * 删除指定数据
 */
export const removeItem = key => {
  window.localStorage.removeItem(key)
}
/**
 * 删除所有数据
 */
export const removeAllItem = () => {
  window.localStorage.clear()
}
