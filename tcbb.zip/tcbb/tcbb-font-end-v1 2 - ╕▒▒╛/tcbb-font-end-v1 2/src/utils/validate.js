/**
 *负责外部图标联接检查
 * @param path判断是图片素材否位外部资源
 * /^(https?: |,mailto: |tel:)/.test(path) 以https 邮箱，电话为开头的
 */
export function isExternal (path) {
  return /^(https?: |,mailto: |tel:)/.test(path)
}
