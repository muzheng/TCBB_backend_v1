<!--负责在登陆后进入主界面-->
<template>
<div class="app-wrapper" :class="[$store.getters.sidebarOpened ? 'openSidebar' : 'hideSidebar']">
  <!--左侧 menu-->
  <!--:style="{ backgroundColor: variables.menuBg} 负责动态管理背景颜色，通过修改variables 中的menuBg动态修改背景颜色-->
  <sidebar class="sidebar-container" :style="{ backgroundColor: variables.menuBg}"></sidebar>
  <!--右侧部分-->
  <div class="main-container">
    <!--吸顶效果-->
    <div class="fixed-header"></div>
    <!--顶部 navbar-->
    <navbar></navbar>
    <!--内容区-->
    <app-main></app-main>
  </div>
</div>
</template>

<script setup>
// 引入组件 将src-->layout--->components文件夹的内容导入
import Sidebar from './components/Sidebar'
import Navbar from './components/Navbar'
import AppMain from './components/AppMain'
import variables from '@/styles/variables.scss'
console.log(variables)
</script>

<style lang="scss" scoped>
@import "src/styles/minxin.scss";
@import "src/styles/variables.scss";
// @import '~@/styles/mixin.scss';
// @import '~@/styles/variables.scss';

.app-wrapper {
  // clearfix 已经在minxin.scss中定义了，直接引用
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
}

.fixed-header {
  position: fixed;
  top: 0;
  right: 0;
  z-index: 9;
  // 动态计算左侧sidebar的宽度 sideBarWidth在 variables.scss中保存
  width: calc(100% - #{$sideBarWidth});
  transition: width 0.28s
}

.hideSidebar .fixed-header {
  width: calc(100% - #{$hideSideBarWidth});
}
</style>
