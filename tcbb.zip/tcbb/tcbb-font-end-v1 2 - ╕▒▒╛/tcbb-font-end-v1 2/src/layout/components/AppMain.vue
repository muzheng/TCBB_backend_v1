<template>
<div class="app-main">
  <router-view></router-view>
</div>
</template>

<script setup>
import {} from 'vue'

</script>

<style lang="scss" scoped>
.app-main {
  // 100vh 为浏览器可视高度 calc 负责计算
  min-height: calc(100vh - 50px);
  width: 100%;
  position: relative;
  overflow: hidden;
  padding: 61px 20px 20px 20px;
  box-sizing: border-box;
}

</style>
