<template>
<div class="navbar">
  <!--渲染左上角按钮-->
  <hamburger class="hamburger-container" />
  <breadcrumb class="breadcrumb-container"></breadcrumb>
  <div class="right-menu">
    <lang-select class="right-menu-item hover-effect"></lang-select>
    <!--渲染头像-->
    <el-dropdown clss="avatar-container" trigger="click">
      <div class="avatar-wrapper">
        <el-avatar shape="square" :size="40" src="./logJPG"></el-avatar>
        <i class="el-icon-s-tools"></i>
      </div>
      <template #dropdown>
        <el-dropdown-menu class="user-dropdown">
          <router-link to="/">
            <el-dropdown-item>{{$t('msg.navBar.home')}}</el-dropdown-item>
            <el-dropdown-item>{{$t('msg.navBar.profile')}}</el-dropdown-item>
            <!--divided 添加一个横线-->
            <el-dropdown-item divided @click="logout">{{$t('msg.navBar.logout')}}</el-dropdown-item>
          </router-link>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</div>
</template>

<script setup>
import {} from 'vue'
import stores from '@/store'
import { useStore } from 'vuex'
import LangSelect from '@/components/langSelect'
// 导入hamburger组件
import Hamburger from '@/components/hamburger'
// 导入面包屑组件
import Breadcrumb from '@/components/Breadcrumb'
console.log(stores.state.user.userInfo)
console.log(stores.getters.userInfo)

const store = useStore()
const logout = () => {
  store.dispatch('user/logout')
}
</script>

<style lang="scss" scoped>
.navbar{
  height: 50px;
  overflow: hidden;
  position: relative;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  .right-menu{
    display: flex;
    align-items: center;
    float:  right;
    padding-right: 16px;

    ::v-deep .right-menu-item {
      display: inline-block;
      padding: 0 18px 0 0;
      font-size: 24px;
      color: #5a5e66;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
      }
    }

    ::v-deep .avatar-container {
      cursor: pointer;
      .avatar-wrapper {
        margin-top: 5px;
        position: relative;
        .el-avatar {
          --el-avatar-background-color: none;
          margin-right: 12px;
        }
      }
    }
  }

  .hamburger-container {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    // 鼠标移动会有一个动画
    // hover 动画
    transition: background 0.5s;

    &:hover {
      background: rgba(0, 0, 0, 0.1);
    }
  }
}

</style>
