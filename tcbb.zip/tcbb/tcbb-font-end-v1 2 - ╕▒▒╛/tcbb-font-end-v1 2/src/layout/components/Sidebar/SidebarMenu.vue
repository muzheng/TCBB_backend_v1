<template>
  <!--:unique-opened="true" 表示每次只能打开一个-->
  <!--router 路由转跳-->
  <!--:collapse 折叠属性   :collapse="!$store.getters.sidebarOpened" 就是与图标取反-->
  <el-menu
    :collapse="!$store.getters.sidebarOpened"
           :unique-opened="true"
           :background-color="$store.getters.cssVar.menuBg"
           :text-color="$store.getters.cssVar.menuText"
           :active-text-color="$store.getters.cssVar.menuActiveText"
           :default-active="activeMenu"
  router>
    <sidebar-item
      v-for="item in routes"
      :key="item.path"
      :route="item"
    ></sidebar-item>
  </el-menu>
</template>

<script setup>
/**
 * getRoutes 获取完整所有路由表
 * 使用路由时候要进行处理，因为路由有一级，二级之分
 * 在utils--> routes处理路由相关，剔除无效数据，剔除多余数据
 *
 */
import { computed } from 'vue'
import { useRouter } from 'vue-router'
// 此两个方法 负责把处理好的路由表展示出来
import { filterRouters, generateMenus } from '@/utils/route'
import SidebarItem from './SidebarItem'

const router = useRouter()
console.log(router.getRoutes())

const routes = computed(() => {
  // 先过滤一遍数据
  const fRoutes = filterRouters(router.getRoutes())
  console.log(fRoutes)
  return generateMenus(fRoutes)
})
console.log(JSON.stringify(routes.value))

// 默认激活属性,
// 冲route获得路径信息
const route = useRouter()
const activeMenu = computed(() => {
  const { path } = route
  return path
})

</script>

<style scoped>

</style>
