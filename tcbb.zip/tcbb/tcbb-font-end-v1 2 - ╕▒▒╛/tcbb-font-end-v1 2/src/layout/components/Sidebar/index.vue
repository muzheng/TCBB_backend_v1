<template>
<div class="">
  <div class="logo-container">
    <h1 class="logo-title" v-if="$store.getters.sidebarOpened">Vitesco</h1>
  </div>
  <!--<sidebar-menu> 为menu菜单过长，提供一个滚动条-->
  <sidebar-menu>

  </sidebar-menu>
</div>
</template>

<script setup>
import {} from 'vue'
import SidebarMenu from './SidebarMenu'
</script>

<style lang="scss" scoped>
.logo-container {
  height: 44px;
  padding: 10px 0 22px 0;
  display: flex;
  align-items: center;
  justify-content: center;
.logo-title {
  margin-left: 10px;
  color: #fff;
  font-weight: 600;
  line-height: 50px;
  font-size: 45px;
  white-space: nowrap;
}
}
</style>
