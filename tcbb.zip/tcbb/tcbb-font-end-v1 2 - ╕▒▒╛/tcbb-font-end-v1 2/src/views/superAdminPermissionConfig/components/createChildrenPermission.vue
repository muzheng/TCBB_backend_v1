<template>
<div class="">创建二级子权限</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped>

</style>
