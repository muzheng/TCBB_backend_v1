<template>
  <div class="">
    <el-card>
      <el-button type="primary">创建</el-button>
    </el-card>
  </div>
  <div>
    <el-card>

    </el-card>
  </div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped>

</style>
