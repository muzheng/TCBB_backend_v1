<template>
  <el-dialog title="学员充值" width="40%" :model-value="modelValue" @close="closed">
    <el-form :model="from">
      <el-form-item label="充值课时数" label-width="100px">
        <el-select  v-model="classCount" placeholder="选择课时">
          <el-option label="10" value="10"></el-option>
          <el-option label="36" value="36"></el-option>
          <el-option label="150" value="150"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="有效天数" label-width="100px">
        <el-input v-model="validity" style="width: 230px"></el-input>
      </el-form-item>
      <el-form-item label="修改课时次数" label-width="100px">
        <el-input v-model="modifyCount" style="width: 230px"></el-input>
      </el-form-item>
      <el-form-item label="充值额度" label-width="100px">
        <el-input v-model="investMoney " style="width: 230px"></el-input>
      </el-form-item>
      <el-form-item label="备注" label-width="100px">
        <el-input type="textarea" v-model="investRemark" style="width: 230px"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="closed">取 消</el-button>
      <el-button type="primary" @click="onInvest">确 定</el-button>
    </template>
  </el-dialog>
</template>
<script setup>
import { defineEmits, defineProps, ref, watch } from 'vue'
import { createInvestMoney } from '@/api/course'
import { ElMessage } from 'element-plus'

const classCount = ref('')
const validity = ref('')
const modifyCount = ref('')
const investMoney = ref('')
const investRemark = ref('')
const id = ref('')

// 接收父组件传递的数据
// 接收父组件传递的数据
const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true
  },
  userId: {
    type: String,
    required: true
  }
})

watch(
  () => props.userId,
  val => {
    id.value = val
    console.log(val)
  }
)

console.log(props)
const emist = defineEmits(['update:modelValue'])
console.log(emist)

const closed = () => {
  emist('update:modelValue', false)
}

const onInvest = () => {
  const newClassCount = classCount.value
  const newValidity = validity.value
  const newModifyCount = modifyCount.value
  const newInvestMoney = investMoney.value
  const newInvestRemark = investRemark.value
  const userid = id.value
  console.log(newClassCount)
  console.log(newValidity)
  console.log(newModifyCount)
  console.log(newInvestMoney)
  console.log(newInvestRemark)
  console.log(id.value)

  if (newClassCount === '' || newValidity === '' || newModifyCount === '' || newInvestMoney === '') {
    ElMessage.warning('填写内容不能为空!')
  } else {
    createInvestMoney({ newClassCount, newValidity, newModifyCount, newInvestMoney, newInvestRemark, userid }).then(res => {
      console.log(res)
    })
  }
}
</script>
