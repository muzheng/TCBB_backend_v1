<template>
  <div class="user-manage-container">
    <el-card class="header">
      <el-form inline="true">
        <el-form-item label="学员卡号"  label-width="100px">
          <el-input :disabled="true" v-model="result.card_number"></el-input>
        </el-form-item>
        <el-form-item label="学员姓名" label-width="100px">
          <el-input :disabled="true" v-model="result.name"></el-input>
        </el-form-item>
        <el-form-item label="当前课时总数" label-width="100px">
          <el-input :disabled="true" v-model="result.class"></el-input>
        </el-form-item>
        <el-form-item label="充值总额度" label-width="100px">
          <el-input :disabled="true" v-model="result.cost_total"></el-input>
        </el-form-item>
        <el-button type="success" @click="onInvest()">充值</el-button>
      </el-form>
    </el-card>
  </div>
  <div>
    <el-card>
      <el-table v-loading="loading" :data="tableData" stripe="true" border="true" style="width: 100%">
        <el-table-column type="index" label="#" width="80"></el-table-column>
        <el-table-column label="订单号" prop="order" width="120"></el-table-column>
        <el-table-column label="充值课时数" prop="course" width="120"></el-table-column>
        <el-table-column label="状态" prop="io_2" width="200"></el-table-column>
        <el-table-column label="剩余有效课时数" prop="surplus" width="120"></el-table-column>
        <el-table-column label="课程激活时间" prop="begin_time" width="150"></el-table-column>
        <el-table-column label="总有效天数" prop="io_1" width="120"></el-table-column>
        <el-table-column label="剩余有效天数" prop="end_time" width="150"></el-table-column>
        <el-table-column label="剩余可修改次数" prop="foul" width="200"></el-table-column>
        <el-table-column label="充值时间" prop="begin_time" width="200"></el-table-column>
        <el-table-column label="更新时间" prop="update_time" width="200"></el-table-column>
        <el-table-column label="操作" width="450">
          <template #default="{ row }">
            <el-button type="success" size="small" @click="onSupply(row)">修改</el-button>
            <el-button type="primary" size="small" @click="onEdit(row)">查看详情</el-button>
            <el-button type="warning" size="small" @click="onGift(row)">终止课程</el-button>
            <el-button size="small" @click="reGift(row)">恢复课程</el-button>
            <el-button type="danger" size="small" @click="onDelete(row)">删除</el-button>

          </template>
        </el-table-column>
      </el-table>
      <el-pagination class="pagination" @size-change="handleSizeChange"
                     @current-change="handCurrentChange"
                     :current-page="page"
                     :page-sizes="[2,5,10,20]"
                     layout="total, sizes, prev, next, jumper"
                     :total="total"
      ></el-pagination>
    </el-card>
  </div>
  <user-invest v-model="createInvestDialogVisible" :userId="selectUserId"></user-invest>
</template>

<script setup>
import { useRoute } from 'vue-router'
import { fetchByID } from '@/api/user-manage'
import { getBuycouresById } from '@/api/course'
import UserInvest from './components/userInvest'
import { ref } from 'vue'

const result = ref({})
const tableData = ref([])
const loading = ref(false)
const selectUserId = ref('')
const createInvestDialogVisible = ref(false)

const route = useRoute()

const id = route.params.id
console.log(id)

const getById = async () => {
  await fetchByID({ id }).then(res => {
    result.value = JSON.parse((res.data)[0])
    console.log(result.value)
  })
}

console.log(getById())

const getBuycourseList = async () => {
  loading.value = true
  getBuycouresById({ id }).then(res => {
    console.log(res)
    tableData.value = res.array
    loading.value = false
  })
}

console.log(getBuycourseList())

const onInvest = () => {
  createInvestDialogVisible.value = true
  selectUserId.value = id
}

</script>

<style scoped>

</style>
