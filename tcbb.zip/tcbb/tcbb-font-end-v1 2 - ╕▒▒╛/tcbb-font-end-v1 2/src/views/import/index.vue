<template>
<div>导入</div>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style scoped>

</style>
