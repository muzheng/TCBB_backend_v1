<template>
  <el-dialog title="创建角色" width="50%" :model-value="modelValue" @close="closed">
    <el-form :model="from">
      <el-form-item label="ID 值" label-width="120px">
        <el-input v-model="id"></el-input>
      </el-form-item>
      <el-form-item label="标题名称" label-width="120px">
        <el-input v-model="title"></el-input>
      </el-form-item>
      <el-form-item label="描述" label-width="120px">
        <el-input v-model="describe"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="closed">取 消</el-button>
      <el-button type="primary" @click="createNewRole">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
// defineEmits表示当窗体关闭时候对外发出的通知， 必须以update: 开头,传入数据名称
// 窗体关闭要监听closed状态
import { ref, defineProps, defineEmits } from 'vue'
import { ElMessage } from 'element-plus'
import { checkRole, createRole } from '@/api/roles'

const id = ref(null)
const title = ref(null)
const describe = ref(null)
// 接收父组件传递的数据
const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true
  }
})
console.log(props)
const emist = defineEmits(['update:modelValue'])
console.log(emist)

const closed = () => {
  emist('update:modelValue', false)
}

const createNewRole = () => {
  // 要处理的问题，
  // 处理 id和title为准
  // 没有相同，创建
  console.log(id)
  checkRole({ id }).then(res => {
    console.log(res.idCount)
    if (res.idCount === 0) {
      // 创建新角色
      createRole({ id, title, describe }).then(res => {
        console.log(res.createRole)
        if ((res.createRole).acknowledged === true) {
          closed()
          ElMessage.warning('信息创建成功')
        }
      })
    } else if (res.idCount === 1) {
      ElMessage.warning('ID 值已经存在')
    }
  })
}
</script>

<style lang="scss" scoped>

</style>
