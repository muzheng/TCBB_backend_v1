<template>
  <el-dialog title="编辑学员基本信息" width="40%" :model-value="modelValue" @close="closed">
    <el-form :model="from">
      <el-form-item label="学员卡号" label-width="100px">
        <el-input :disabled="true" v-model="result.card_number"></el-input>
      </el-form-item>
      <el-form-item label="学员姓名" label-width="100px">
        <el-input v-model="result.name"></el-input>
      </el-form-item>
      <el-form-item label="性别" label-width="100px">
        <el-select  v-model="result.sexual" placeholder="选择性别">
          <el-option label="男" value="男"></el-option>
          <el-option label="女" value="女"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="联系方式" label-width="100px">
        <el-input v-model="result.parent_tel"></el-input>
      </el-form-item>
      <el-form-item label="出生日期" label-width="100px">
        <el-input v-model="result.birthday"></el-input>
      </el-form-item>
      <el-form-item label="备注" label-width="100px">
        <el-input type="textarea" v-model="result.remark"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="closed">取 消</el-button>
      <el-button type="primary" @click="updateUser">更 新</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch } from 'vue'
import { updateUserBaseInfo, fetchByID } from '@/api/user-manage'
import { ElMessage } from 'element-plus'

// 接收父组件传递的数据
const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true
  },
  userId: {
    type: String,
    required: true
  }
})

const result = ref({})
watch(
  () => props.userId,
  val => {
    console.log(val)
    fetchByID({ val }).then(res => {
      result.value = JSON.parse((res.data)[0])
      console.log(result.value)
    })
  }
)
console.log(() => props)
console.log(props.userId)
console.log(props.modelValue)
console.log('ceshi ')

const emist = defineEmits(['update:modelValue', 'userId'])
console.log(emist)

const closed = () => {
  emist('update:modelValue', false)
}

const updateUser = () => {
  console.log(result.value.name)
  // const newCard = card.value
  const userId = result.value._id
  const updateName = result.value.name
  const updateSexual = result.value.sexual
  const updateParent = result.value.parent_tel
  const updateBirthday = result.value.birthday
  const updateRemark = result.value.remark

  if (updateName === '' || updateSexual === '' || updateBirthday === '' || updateParent === '') {
    ElMessage.warning('填写内容不能为空')
  } else {
    updateUserBaseInfo({ userId, updateName, updateSexual, updateParent, updateBirthday, updateRemark }).then(res => {
      console.log(res)
      if (res.data.modified === 1) {
        ElMessage.success('学员信息更新成功')
      }
    })
  }
}

</script>

<style lang="scss" scoped>

</style>
