<template>
  <el-dialog title="创建学员" width="40%" :model-value="modelValue" @close="closed">
    <el-form :model="from">
      <el-form-item label="学员卡号" label-width="100px">
        <el-input v-model="card"></el-input>
      </el-form-item>
      <el-form-item label="学员姓名" label-width="100px">
        <el-input v-model="name"></el-input>
      </el-form-item>
      <el-form-item label="性别" label-width="100px">
        <el-select  v-model="sexual" placeholder="选择性别">
          <el-option label="男" value="男"></el-option>
          <el-option label="女" value="女"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="联系方式" label-width="100px">
        <el-input v-model="parent_tel"></el-input>
      </el-form-item>
      <el-form-item label="出生日期" label-width="100px">
        <el-input v-model="birthday"></el-input>
      </el-form-item>
      <el-form-item label="备注" label-width="100px">
        <el-input type="textarea" v-model="remark"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="closed">取 消</el-button>
      <el-button type="primary" @click="createNewUser">确 定</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, defineProps, defineEmits } from 'vue'
import { checkNewUserCard, createUser } from '@/api/user-manage'
import { ElMessage } from 'element-plus'

const card = ref('')
const name = ref('')
const sexual = ref('')
// eslint-disable-next-line camelcase
const parent_tel = ref('')
const birthday = ref('')
const remark = ref('')

// 接收父组件传递的数据
const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true
  }
})
console.log(props)
const emist = defineEmits(['update:modelValue'])
console.log(emist)

const closed = () => {
  emist('update:modelValue', false)
}

const createNewUser = () => {
  console.log(card.value)
  const newCard = card.value
  const newName = name.value
  const newSexual = sexual.value
  const newParent = parent_tel.value
  const newBirthday = birthday.value
  const newRemark = remark.value

  if (newCard === '' || newName === '' || newSexual === '' || newBirthday === '' || newParent === '') {
    ElMessage.warning('填写内容不能为空')
  } else {
    checkNewUserCard({ newCard }).then(res => {
      console.log(res)
      if (parseInt(res.data) === 0) {
        // 执行创建方法
        createUser({ newCard, newName, newSexual, newParent, newBirthday, newRemark }).then(res => {
          console.log(res.data.errmsg)
          if (res.data.errmsg === 'ok') {
            closed()
            ElMessage.success('学员信息创建成功')
          }
        })
      } else if (parseInt(res.data) >= 1) {
        ElMessage.warning('此卡号已经存在')
      }
    })
  }
}

</script>

<style lang="scss" scoped>

</style>
