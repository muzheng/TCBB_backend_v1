<template>
<div class="user-manage-container">
  <el-card class="header">
    <div>
      <el-button type="success" @click="onCreateUser">创建新学员</el-button>
      <el-button type="primary" @click="onSearchUser">学员信息查询</el-button>
    </div>
  </el-card>
</div>
  <div>
    <el-card>
      <el-table v-loading="loading" :data="tableData" stripe="true" border="true" style="width: 100%">
        <el-table-column type="index" label="#" width="80"></el-table-column>
        <el-table-column label="会员卡号" prop="card_number" width="120"></el-table-column>
        <el-table-column label="姓名" prop="name" width="120"></el-table-column>
        <el-table-column label="性别" prop="sexual" width="100"></el-table-column>
        <el-table-column label="出生日期" prop="birthday" width="120"></el-table-column>
        <el-table-column label="联系方式" prop="parent_tel" width="150"></el-table-column>
        <el-table-column label="剩余总课时数" prop="class" width="120"></el-table-column>
        <el-table-column label="充值总额（元）" prop="cost_total" width="150"></el-table-column>
        <el-table-column label="信息创建时间" prop="create_time" width="200"></el-table-column>
        <el-table-column label="信息更新时间" prop="update_time" width="200"></el-table-column>
        <el-table-column label="操作" width="600">
          <template #default="{ row }">
            <el-button type="success" size="small" @click="onSupply(row)">充值</el-button>
            <el-button type="primary" size="small" @click="onEdit(row)">编辑</el-button>
            <el-button type="warning" size="small" @click="onGift(row)">赠送</el-button>
            <el-button type="info" size="small" @click="investHistory(row)">充值记录</el-button>
            <el-button type="success" size="small" @click="onChangxun(scope.row)">长训减课时</el-button>
            <el-button type="danger" size="small" @click="onDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination class="pagination" @size-change="handleSizeChange"
                     @current-change="handCurrentChange"
                     :current-page="page"
                     :page-sizes="[2,5,10,20]"
                     layout="total, sizes, prev, next, jumper"
                     :total="total"
      ></el-pagination>
    </el-card>
  </div>
  <create-user v-model="createUserDialogVisible"></create-user>
  <search-user v-model="searchUserDiaglogVisible"></search-user>
  <edit-user v-model="editUserDiaglogVisible" :userId="selectUserId"></edit-user>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { getUserManageList } from '@/api/user-manage'
import CreateUser from './components/createUser'
import SearchUser from './components/searchUser'
import EditUser from './components/editUser'

const createUserDialogVisible = ref(false)
const searchUserDiaglogVisible = ref(false)
const editUserDiaglogVisible = ref(false)
const selectUserId = ref('')

const router = useRouter()

// 相关数据
const tableData = ref([])
const total = ref(0)
const page = ref(1)
const size = ref(10)
const loading = ref(false)
/**
 * 监听创建学员按钮的状态
 */
watch(createUserDialogVisible, val => {
  console.log(val)
  if (val === false) {
    getUserList()
  }
})

watch(editUserDiaglogVisible, val => {
  if (!val) {
    selectUserId.value = ''
  }
})

/**
 * 获得用户信息列表
 * @returns {Promise<void>}
 */
const getUserList = async () => {
  loading.value = true
  await getUserManageList({
    page: page.value,
    size: size.value
  }).then(res => {
    tableData.value = res.list
    total.value = res.Total
    console.log(tableData)
    loading.value = false
  })
}

console.log(getUserList())

/**
 * 充值方法
 * @param row
 */

const onSupply = (row) => {
  console.log(row._id)
  selectUserId.value = row._id
  router.push(`/user/reChange/${row._id}`)
}

/**
 * 学员信息编辑
 */

const onEdit = (row) => {
  console.log(row._id)
  selectUserId.value = row._id
  editUserDiaglogVisible.value = true
  // router.push(`/user/edit/${row._id}`)
}

// 分页相关
/**
 * size 改变触发
 */
const handleSizeChange = currentSize => {
  size.value = currentSize
  getUserList()
}

/**
 * 页码改变触发
 */
const handCurrentChange = currentPage => {
  page.value = currentPage
  getUserList()
}

/**
 * 创建新学员
 */
const onCreateUser = () => {
  createUserDialogVisible.value = true
  console.log('creste')
}
/**
 * 查询学员信息
 */
const onSearchUser = () => {
  searchUserDiaglogVisible.value = true
}

</script>

<style lang="scss" scoped>
.user-manage-container{
  .header {
    margin-bottom: 22px;
    text-align: right;
  }
}
.pagination {
  margin-top: 20px;
  text-align: center;
}
</style>
