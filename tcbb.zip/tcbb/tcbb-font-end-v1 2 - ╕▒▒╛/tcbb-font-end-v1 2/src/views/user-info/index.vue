<template>
<div>用户信息</div>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style scoped>

</style>
