<template>
<div class="">备件管理</div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>
