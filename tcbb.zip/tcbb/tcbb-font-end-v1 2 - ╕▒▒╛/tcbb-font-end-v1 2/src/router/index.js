/**
 * createWebHashHistory路由模式路径带#号
 * 路由进行冷加载
 * path： 带有“/” 指定路径
 * component 导入组件，通过import导入
 * meta: 为样式
 * 注意，meta 和title必须填写，此处可以用来定制动态路由左侧的按钮显示
 * redirect: 重定向
 * publicRoutes: 公开路由表
 * privateRoutes: 私有路由表
 * 要在appMain中指定路由出口
 */
import { createRouter, createWebHashHistory } from 'vue-router'
// 提前预处理，在后面代码直接使用layout，减少工作量
import layout from '@/layout/index'

const privateRoutes = [
  {
    path: '/user',
    component: layout,
    redirect: '/user/manage',
    meta: {
      title: 'user',
      icon: 'personnel'
    },
    children: [
      // 用户管理
      {
        path: '/user/manage',
        component: () => import('@/views/user-manage/index'),
        meta: {
          title: 'userManage',
          icon: 'personnel-manage'
        }
      },
      // 用户充值
      {
        path: '/user/reChange/:id',
        name: 'reChange',
        component: () => import('@/views/user-rechange/index'),
        meta: {
          title: '用户充值'
        }
      },

      // 角色列表
      {
        path: '/user/role',
        component: () => import('@/views/role-list/index'),
        meta: {
          title: 'roleList',
          icon: 'role'
        }
      },
      // 权限列表
      {
        path: '/user/permission',
        component: () => import('@/views/permision-list/index'),
        meta: {
          title: 'permissionList',
          icon: 'permission'
        }
      },
      // 用户信息
      {
        path: '/user/info/:id',
        component: () => import('@/views/user-info/index'),
        meta: {
          title: 'userInfo'
        }
      },
      // 导入
      {
        path: '/user/import',
        component: () => import('@/views/import/index'),
        meta: {
          title: 'excel导入'
        }
      }
    ]
  },
  {
    path: '/management',
    component: layout,
    meta: {
      title: 'management',
      icon: 'el-icon-eleme'
    },
    children: [
      {
        path: '/management/dashboard',
        component: () => import('@/views/dashboard/index'),
        meta: {
          title: 'dashboard',
          icon: 'el-icon-s-data'
        }
      },
      {
        path: '/management/config',
        component: () => import('@/views/management-config/index'),
        meta: {
          title: 'config',
          icon: 'el-icon-setting'
        }
      }
    ]
  },
  {
    path: '/operator',
    component: layout,
    meta: {
      title: 'operator',
      icon: 'el-icon-ice-cream'
    },
    children: [
      {
        path: '/operator/issue',
        component: () => import('@/views/operator-Fixture-issue/index'),
        meta: {
          title: 'issue',
          icon: 'el-icon-price-tag'
        }
      }
    ]
  },
  {
    path: '/technician',
    component: layout,
    meta: {
      title: 'technician',
      icon: 'el-icon-s-operation'
    }
  },
  {
    path: '/analyzer',
    component: layout,
    meta: {
      title: 'ANATechnician',
      icon: 'el-icon-s-operation'
    }
  },
  {
    path: '/engineer',
    component: layout,
    meta: {
      title: 'engineer',
      icon: 'el-icon-s-finance'
    }
  },
  {
    path: '/superAdminConfig',
    component: layout,
    meta: {
      title: 'superAdminConfig',
      icon: 'el-icon-s-finance'
    },
    children: [
      {
        path: '/superAdminConfig/ruleConfig',
        component: () => import('@/views/superAdminConfig/index'),
        meta: {
          title: 'ruleConfig',
          icon: 'el-icon-price-tag'
        }
      },
      {
        path: '/superAdminConfig/permissionConfig',
        component: () => import('@/views/superAdminPermissionConfig/index'),
        meta: {
          title: 'permissionConfig',
          icon: 'el-icon-price-tag'
        }
      },
      {
        path: '/superAdminConfig/superAdminCreate',
        component: () => import('@/views/superAdminCreate/index'),
        meta: {
          title: 'superAdminCreate',
          icon: 'el-icon-price-tag'
        }
      }
    ]
  }

]

const publicRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index')
  },
  {
    path: '/',
    // 注意：带有路径“/”的记录中的组件“默认”是一个不返回 Promise 的函数
    component: layout,
    redirect: '/profile',
    children: [
      {
        path: '/profile',
        name: 'profile',
        component: () => import('@/views/profile/index'),
        meta: {
          title: 'profile',
          icon: 'el-icon-user'
        }
      },
      {
        path: '/404',
        name: '404',
        component: () => import('@/views/error-page/404')
      },
      {
        path: '/401',
        name: '401',
        component: () => import('@/views/error-page/401')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes: [...publicRoutes, ...privateRoutes]
})

export default router
