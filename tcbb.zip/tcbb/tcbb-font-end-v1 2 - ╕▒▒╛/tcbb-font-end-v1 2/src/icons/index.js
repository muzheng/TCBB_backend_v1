// 1. 导入所有svg 图标
// 2. 完成SvgIcon全局注册
/**
 * 导入SvgIcon 组件
 */
import SvgIcon from '@/components/SvgIcon'
/**
 * require.context(directory,useSubdirectories,regExp)
 * directory:表示检索的目录
 * useSubdirectories：表示是否检索子文件夹
 * regExp:匹配文件的正则表达式,一般是文件名
 * 返回一个require 返回的require就是图标列表用于导入
 */
const svgRequire = require.context('./svg', false, /\.svg$/)

/**
 * 该函数提供三个属性，可以通过svgRequire。keys（） 获得所有的svg图标
 * 遍历图标，把图标作为request参数参入到svgRequire导入函数中，完成本地svg图标
 */
console.log(svgRequire.keys())
svgRequire.keys().forEach(svgIcon => svgRequire(svgIcon))

/**
 * 导出一个幻术
 * @param app ：相当与main.js中const app = createApp(App)中的 app
 * 这样就将SvgIcon组件注册为全局组件
 */
export default app => {
  app.component('svg-icon', SvgIcon)
}
