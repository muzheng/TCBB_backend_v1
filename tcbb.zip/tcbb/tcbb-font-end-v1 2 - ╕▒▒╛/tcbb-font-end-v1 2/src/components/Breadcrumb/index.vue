<!--创建面包屑，属于快速进入界面的一种-->
<!--此组件要使用，必须在navBar中进行导入-->
<!-- separator="/" 表示已/为间隔-->
<template>
  <el-breadcrumb class="breadcrumb" separator="/">
    <transition-group name="breadcrumb">
      <!--在这里进行动态面包屑的渲染-->
      <el-breadcrumb-item v-for = "(item, index) in breadcrumData" :key="item.path" >
        <!--不可点击-->
        <span
          class="no-redirect"
          v-if = "index === breadcrumData.length - 1 "
        >
      {{item.meta.title}}</span>
        <!--可点击-->
        <span class="redirect" v-else @click="onLinkChick(item)">{{item.meta.title}}</span>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script setup>
import { watch, ref } from 'vue'
// 获得路由
import { useRoute } from 'vue-router'

const breadcrumData = ref([])
const route = useRoute()
// 生成数组数据
const getBreadcrumData = () => {
  // 当前路由的标准化路由记录
  breadcrumData.value = route.matched.filter(item => item.meta && item.meta.title)
  console.log(route.matched)
  console.log(breadcrumData)
}
// 监听路由变化
// immediate: true 刚进入组件触发一次

watch(route, () => {
  // 监听时候触发这个方法
  getBreadcrumData()
},
{
  immediate: true
}
)
</script>

<style lang="scss" scoped>
.breadcrumb {
  display: inline-block;
  font-size: 14px;
  line-height: 50px;
  margin-left: 8px;

  ::v-deep .no-redirect {
    color: #97a8be;
    cursor: text;
    .redirect {
      color: #666;
      font-weight: 600;
    }
  }
}

</style>
