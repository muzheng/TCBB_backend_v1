const Router=require('koa-router')
const router=new Router()

const getAccessToken=require('../untils/getAccessToken.js')
const rp=require('request-promise')

const env='tcbbcloudtest-0g3iqqxb09830af5'

/**
 * 获得用户充值或者赠送课程列表
 *
 */

// 从数据库中user集合中通过id 获得userid
router.post('/getBuycouresListById',async (ctx,next) => {
    const ACCESS_TOKEN=await getAccessToken()

    const params=ctx.request.body
    console.log(params)

    const Id=params.id
    console.log(Id+"  数据库ID")

    var array=[]

    var options={
        method:'POST',
        uri: `https://api.weixin.qq.com/tcb/databasequery?access_token=${ACCESS_TOKEN}`,

        body:{

            query:`db.collection('users').doc('${params.id}').get()`,
            env: `${env}`,

        },

        json: true // Automatically stringifies the body to JSON

    };

    const userid=await rp(options).then(res=>{

        const userid=JSON.parse(res.data).io_2
        console.log(userid)
        return userid
    })

    console.log(userid)

    // 通过userid 获得该学员的充值或者课程赠送记录
    var options={
        method:'POST',
        uri: `https://api.weixin.qq.com/tcb/databasequery?access_token=${ACCESS_TOKEN}`,

        body:{

            query:`db.collection('buycourse').where({userid:'${userid}'}).limit(100).get()`,
            env: `${env}`,

        },

        json: true // Automatically stringifies the body to JSON

    };

    await rp(options).then(res=>{
        console.log(res)
        for(var i=0;i<res.data.length;i++){

            array.push(JSON.parse(res.data[i]))

        }

        return array
    });

    console.log(array)

    ctx.body={
        success:true,
        data:{
            array
        },
        message:'success',
        code:20000
    }
})

/**
 * 用户充值模块
 */
router.post('/createInvestMoney',async (ctx, next) => {
    const ACCESS_TOKEN=await getAccessToken()

    const params=ctx.request.body
    console.log(params)
    console.log(params.newClassCount)

    // 通过user 的ID获得课时总数，充值总额等参数
    var options = {
        method: 'POST',
        uri: `https://api.weixin.qq.com/tcb/databasequery?access_token=${ACCESS_TOKEN}`,

        body: {
            query:`db.collection('users').doc('${params.userid}').get()`,
            env: `${env}`,

        },

        json: true // Automatically stringifies the body to JSON
    };

    const data=await rp(options).then(res=>{
        console.log(res)
        return JSON.parse(res.data)
    })
    console.log(data.class)
    var beforeUserClassCount=data.class
    var beforeUserClassMoney=data.cost_total

    var investMoney=params.newInvestMoney
    var investClassCount=params. newClassCount

    var total_count=parseInt(beforeUserClassCount)+parseInt(investClassCount)
    var total_money=parseInt(beforeUserClassMoney)+parseInt(investMoney)

    console.log(total_count)
    console.log(total_money)
})

/**
 * 将模块接口暴露
 */
module.exports=router
